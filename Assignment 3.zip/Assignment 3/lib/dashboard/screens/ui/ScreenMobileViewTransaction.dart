import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:assignment_1/dashboard/models/ModelDocuments.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf_viewer_plugin/pdf_viewer_plugin.dart';

import '../../../utils/ThemeColors.dart';

class ScreenMobileViewTransaction extends StatelessWidget {
  const ScreenMobileViewTransaction({
    super.key,
    required this.transaction,
  });

  final Transaction transaction;

  @override
  Widget build(BuildContext context) {
    final scaffoldMessengerContext = ScaffoldMessenger.of(context);

    return Scaffold(
      appBar: AppBar(

        automaticallyImplyLeading: false,


        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(
            Icons.arrow_back_ios,
            color: Colors.grey,
            size: 16,
          ),
        ),


        title: const Text(
          " Document",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 16,
            fontFamily: "Roboto",
            fontWeight: FontWeight.w600,
            color: Colors.black,
          ),
        ),


        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(
          vertical: 20.0,
          horizontal: 19.0,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            SizedBox(
              height: 62,
              child: getDisableTextField(
                label: "Transaction Address",
                value: TextEditingController(
                  text: transaction.address,
                ),
              ),
            ),

            /// Padding
            const SizedBox(
              height: 30,
            ),


            SizedBox(
              height: 62,
              child: getDisableTextField(
                label: "Transaction ID",
                value: TextEditingController(
                  text: "#${transaction.transactionId}",
                ),
              ),
            ),


            const SizedBox(
              height: 20,
            ),


            getListOfDocuments(
              height: MediaQuery.of(context).size.height * 0.3,
              scaffoldMessengerContext: scaffoldMessengerContext,
            ),
          ],
        ),
      ),
    );
  }


  getDisableTextField({
    required String label,
    required TextEditingController value,
  }) =>
      TextField(

        controller: value,

        enabled: false,

        style: TextStyle(
          fontSize: 16,
          fontFamily: "Roboto",
          fontWeight: FontWeight.w400,
          color: ThemeColors.fontPrimaryDark,
        ),
        decoration: InputDecoration(
          label: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              fontFamily: "Roboto",
              fontWeight: FontWeight.w400,
              color: ThemeColors.fontPrimaryLight,
            ),
          ),
          border: UnderlineInputBorder(
            borderSide: BorderSide(
              color: ThemeColors.fontPrimaryLight,
            ),
          ),
        ),
      );

  getListOfDocuments({required double height, required scaffoldMessengerContext,}) => SizedBox(
        height: height,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Document Name",
              style: TextStyle(
                fontSize: 12,
                fontFamily: "Roboto",
                fontWeight: FontWeight.w400,
                color: ThemeColors.fontPrimaryLight,
              ),
            ),

            const SizedBox(
              height: 08,
            ),

            Expanded(
              child: ListView.separated(
                separatorBuilder: (context, index) => const SizedBox(
                  height: 16,
                ),
                itemBuilder: (context, index) => ListTile(
                  contentPadding: const EdgeInsets.all(0),
                  title: Text(
                    transaction.documents[index].title,
                    style: TextStyle(
                      fontSize: 16,
                      fontFamily: "Roboto",
                      fontWeight: FontWeight.w400,
                      color: ThemeColors.fontPrimaryDark,
                    ),
                  ),
                  trailing: IconButton(
                    onPressed: () async {
                      final res = await http.get(Uri.parse(transaction.documents[index].url));
                      final bytes = res.bodyBytes;
                      final dir = await getApplicationDocumentsDirectory();
                      final file = File("${dir.path}dummyPdf.pdf");
                      await file.writeAsBytes(bytes, flush: true);
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => Scaffold(
                            appBar: AppBar(
                              automaticallyImplyLeading: true,
                            ),
                            body: Container(
                              width: double.infinity,
                              height: double.infinity,
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: const Color.fromRGBO(
                                    48,
                                    48,
                                    48,
                                    0.05,
                                  ),
                                  width: 1,
                                ),
                              ),
                              child: PdfView(path: file.path,),),
                          ),
                        ),
                      );
                    },
                    icon: Icon(
                      Icons.remove_red_eye_outlined,
                      color: ThemeColors.iconPrimary,
                      size: 22,
                    ),
                  ),

                ),
                itemCount: transaction.documents.length,
              ),
            ),
          ],
        ),
      );
}
